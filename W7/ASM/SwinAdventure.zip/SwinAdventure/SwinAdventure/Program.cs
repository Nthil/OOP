﻿// See https://aka.ms/new-console-template for more information

using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
namespace SwinAdventure
{
    public class Program
    {
        static void LookCommandExe(Command l, string input, Player player)
        {
            Console.WriteLine(l.Execute(player, input.Split()));

        }

        static void Main(string[] args)
        {
            //Greeting with information 
            string name, desc;
            string help = "Error with:\n-look\n\nGetting Information:\n-look at me (show player's details and items)\n-look at bag (show items in player's bag)\n\nGetting item description:\nlook at {item}\nlook at {item} in me\nlook at {item} in bag\nType 'quit' to log out\n\n";

            Message greetings;
            greetings = new Message("This is SwinAdventure!!!\nSay 'help' if you need any assistance!\n\nNow, Let's get started!!\n");
            greetings.Print();
            Console.WriteLine("Press to continue...");
            Console.ReadLine();

            //Get the player's name and description from the user --> create objects
            Console.Write("Setting up player:\nPlayer Name: ");
            name = Console.ReadLine();
            Console.Write("Player Description: ");
            desc = Console.ReadLine();
            Player player = new Player(name, desc);

            //Set up location
            Location myroom = new Location("My Room", $"This is my room");
            player.Location = myroom; //The player initial location

            //The list of items in inventory (bag)
            Item shovel = new Item(new string[] { "shovel" }, "a shovel", "This is a shovel");
            Item sword = new Item(new string[] { "sword" }, "a sword", "This is a sword");
            Item diamond = new Item(new string[] { "diamond" }, "a diamond", "This is a diamond");
            Item mora = new Item(new string[] { "mora" }, "a mora", "This is a mora");
            Item gem = new Item(new string[] { "gem" }, "a gem", "This is a gem");
            Item primogem = new Item(new string[] { "primogem" }, "a primogem", "This is a primogem");
            
            //Location items
            myroom.Inventory.Put(mora);
            myroom.Inventory.Put(gem);
            myroom.Inventory.Put(primogem);
            
            //Create a bag
            Bag bag = new Bag(new string[] { $"bag" }, $"{player.Name}'s bag", $"This is {player.Name}'s bag");
           
            //Create two items and add them to the the player's inventory
            player.Inventory.Put(shovel); 
            player.Inventory.Put(sword);
            
            player.Inventory.Put(bag); //Add bag to the player's inventory
            bag.Inventory.Put(diamond);
            
            //Proccessing input command
            string _input;
            Command l = new LookCommand();

            while (true)
            {
                Console.Write("Command: ");
                _input = Console.ReadLine();
                if (_input == "quit")
                {
                    break;
                }
                else if (_input == "help")
                {
                    Console.Write(help);
                }
                else
                {
                    LookCommandExe(l, _input, player);
                }

            }
        }
    }
    /*
    public class Program
    {
        public static void Main()
        {

            // ************* Set up player

            // Get the player's name and description from the user, and use these details to create a Player object

            string _name, _description;
            Console.WriteLine("Player name:");
            _name = Console.ReadLine();

            Console.WriteLine("Player description:");
            _description = Console.ReadLine();

            Player player = new Player(_name, _description);


            // Create two items and add them to the the player's inventory
            // Create a bag and add it to the player's inventory
            // Create another item and add it to the bag



            // ************* Set up items

            Item pen = new Item(new string[] { "pen" }, "a pen", "This is a pen");
            Item phone = new Item(new string[] { "phone" }, "a phone", "This is a phone");
            Item laptop = new Item(new string[] { "laptop" }, "a laptop", "This is a laptop");
            Item sofa = new Item(new string[] { "sofa" }, "a sofa", "This is a sofa");
            Item tv = new Item(new string[] { "tv" }, "a tv", "This is a tv");
            Item table = new Item(new string[] { "table" }, "a table", "This is a table");


            // ************* Set up inventory

            Bag bag = new Bag(new string[] { "bag" }, $"{player.Name}'s bag", $"This is {player.Name} bag");

            player.Inventory.Put(pen);
            player.Inventory.Put(phone);
            player.Inventory.Put(bag);
            bag.Inventory.Put(laptop);


            // ************* Set up location
            Location myroom = new Location(new string[] { "location", "location description" }, $"{player.Name}'s room", $"This is {player.Name}'s room");
            player.Location = myroom;


            // ************* Set up location items
            myroom.Inventory.Put(sofa);
            myroom.Inventory.Put(tv);
            myroom.Inventory.Put(table);


            // Loop reading commands from the user, and getting the look command to execute them
            while (true)
            {
                string _input;
                LookCommand _command = new LookCommand();
                Console.WriteLine("Enter command: ");
                _input = Console.ReadLine();

                if (_input == "quit")
                {
                    break;
                }
                else
                {
                    Console.WriteLine(_command.Execute(player, _input.Split(' ')));

                }
            }
        }
    }
    */
}
