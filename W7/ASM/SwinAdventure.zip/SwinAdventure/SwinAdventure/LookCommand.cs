﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwinAdventure
{
    public class LookCommand : Command
    {
        public LookCommand() : base(new string[] { "look" })
        {
        }

        public override string Execute(Player p, string[] text)
        {
            IHaveInventory _container;
            string _itemid;
            string error = "Error in look input.";
            //text == look at I in C
            if (text[0].ToLower() != "look") //Check if the first word is “look”
                return error;

            switch (text.Length)
            {
                case 1:
                    _container = p;
                    _itemid = "location";
                    break;

                case 3:    //If there are 3 elements 
                    if (text[1].ToLower() != "at") //Check if the second word is “at”
                        return "What do you want to look at?";
                    _container = (IHaveInventory)p; //the container is the player
                    _itemid = text[2];
                    break;

                case 5:  //If there are 5 elements 
                    _container = FetchContainer(p, text[4]);  //the container id is the 5th word
                    if (_container == null) //Check if container doesn't exist
                        return "Could not find " + text[4];
                    _itemid = text[2];
                    break;

                default:
                    return error;  ///////////////
            }
            return LookAtIn(_itemid, _container);
        }

        private IHaveInventory FetchContainer(Player p, string containerId)
        {
            return p.Locate(containerId) as IHaveInventory;
        }

        private string LookAtIn(string thingId, IHaveInventory container)
        {
            if (container.Locate(thingId) != null)
                return container.Locate(thingId).FullDescription; // "In 'name' you can see: 'item'

            return "Couldn't find " + thingId;    // check if item doesn't exist
        }
    }
    /*
    public class LookCommand : Command
    {
        public LookCommand() : base(new string[] { "look" })
        {

        }

        public override string Execute(Player p, string[] text)
        {
            if (!new[] { 3, 5 }.Contains(text.Length))
            {
                return "I don't know how to look like that\n";
            }

            if (text[0] != "look")
            {
                return "Error in look input\n";
            }

            if (text[1] != "at")
            {
                return "What do you want to look at?\n";
            }

            if (text.Length == 5)
            {
                string _itemid = text[2];
                string _container = text[4];
                if (text[3] != "in")
                {
                    return "What do you want to look in?\n";
                }

                IHaveInventory container = FetchContainer(p, _container);
                if (container is null)
                {
                    return $"I cannot find the {_itemid} in the {_container}\n";
                }
                return LookAtIn(_itemid, container);
            }

            if (text.Length == 3)
            {
                string _itemid = text[2];
                return LookAtIn(_itemid, p as IHaveInventory);
            }
            return "";
        }

        private IHaveInventory FetchContainer(Player p, string containerId)
        {
            if (p.AreYou(containerId))
            {
                return p;
            }
            return (IHaveInventory)p.Locate(containerId);
        }

        private string LookAtIn(string thingId, IHaveInventory container)
        {
            if (container.Locate(thingId) != null)
            {
                return container.Locate(thingId).FullDescription;
            }

            return $"I cannot find the {thingId}";
        }
    }
*/
}
