﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwinAdventure
{
    public class LocationTest
    {
        Player p = new Player("Thi", "This is Thi");
        Location l = new Location("MyRoom", "This is my room");
        Item gem = new Item(new string[] { "gem" }, "a gem", "This is a gem");


        [SetUp]
        public void Setup()
        {

        }

        //Locations can identify themselves

        [Test]
        public void TestLookCommand()  
        {
            p.Location = l;
            bool actual = l.AreYou("location");
            Assert.IsTrue(actual);
        }

        [Test]
        public void TestNotLookCommand()
        {
            p.Location = l;
            bool actual = l.AreYou("hi");
            Assert.IsFalse(actual);
        }

        //

        [Test]
        public void TestPLayerHasLocation() //Players can locate items in their location
        {
            p.Location = l;
            GameObject expect = l;
            GameObject actual = p.Locate("location");
            Assert.AreEqual(actual, expect);
        }

        [Test]
        public void TestLocationsLocateItems() //Locations can locate items they have
        {
            l.Inventory.Put(gem);
            GameObject expect = gem;
            GameObject actual = l.Locate("gem");
            Assert.AreEqual(actual, expect);
        }
    }
}
